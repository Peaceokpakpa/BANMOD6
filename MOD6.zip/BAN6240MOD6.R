# Install Keras and TensorFlow
install.packages("keras")
library(keras)
install_keras()  # Installs both Keras and TensorFlow
install.packages("reticulate")
install.packages("ggplot2")
install.packages("dplyr")
library(keras)
mnist <- dataset_fashion_mnist()
x_train <- mnist$train$x / 255
x_test <- mnist$test$x / 255
y_train <- mnist$train$y
y_test <- mnist$test$y
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

model %>% compile(
  loss = 'sparse_categorical_crossentropy',
  optimizer = optimizer_adam(),
  metrics = c('accuracy')
)

model %>% fit(x_train, y_train, epochs = 10, validation_data = list(x_test, y_test))
predictions <- model %>% predict(x_test[1:2,,,drop=FALSE])
print(predictions)



